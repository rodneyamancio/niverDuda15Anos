import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { event, formattedDate, formattedTime } from "@/config/event";
import ResponseButtons from "./response-buttons";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ token: string }> };

export default async function InvitePage({ params }: Props) {
  const { token } = await params;
  const guest = await prisma.guest.findUnique({ where: { token } });
  if (!guest) notFound();

  const firstName = guest.name.split(" ")[0];

  return (
    <main className="min-h-screen flex items-center justify-center px-4 py-12 bg-gradient-to-b from-royal-100 via-royal-50 to-royal-50">
      <div className="w-full max-w-lg">
        <div className="bg-white rounded-3xl shadow-xl shadow-royal-500/10 overflow-hidden">
          <div className="bg-gradient-to-br from-royal-700 to-royal-500 px-8 py-12 text-center">
            <p className="text-royal-200 text-xs tracking-[0.4em] uppercase">Save the Date</p>
            <h1 className="[font-family:var(--font-display)] text-4xl md:text-5xl text-white mt-4">
              {event.name}
            </h1>
            <div className="mt-6 inline-block border-t border-b border-white/30 py-3 px-6">
              <p className="text-white text-lg capitalize">{formattedDate()}</p>
              <p className="text-royal-200 text-sm mt-1">
                às {formattedTime()} · {event.venue}
                {event.city ? ` — ${event.city}` : ""}
              </p>
            </div>
          </div>

          <div className="px-8 py-10 text-center">
            <p className="text-xl text-royal-800">
              Olá, <span className="font-semibold">{firstName}</span>! 💜
            </p>
            <p className="mt-3 text-royal-800/70 leading-relaxed">
              A Duda vai completar 15 anos e você é um convidado muito especial. Reserve essa data
              — o convite oficial com todos os detalhes chega em breve!
            </p>

            <ResponseButtons token={token} initialStatus={guest.saveTheDate} />
          </div>
        </div>

        <p className="text-center text-xs text-royal-800/40 mt-6">
          Convite pessoal e intransferível de {guest.name}
        </p>
      </div>
    </main>
  );
}
