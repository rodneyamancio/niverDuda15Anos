import type { Metadata } from "next";
import "./globals.css";
import { event } from "@/config/event";

export const metadata: Metadata = {
  title: event.name,
  description: `Save the Date — ${event.name}`,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className="antialiased min-h-screen">{children}</body>
    </html>
  );
}
