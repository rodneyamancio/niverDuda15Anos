import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { isAdmin } from "@/lib/auth";
import { sendInvite } from "@/lib/send";

const sendSchema = z.object({
  channels: z.array(z.enum(["email", "whatsapp"])).min(1, "Escolha pelo menos um canal"),
});

type Params = { params: Promise<{ id: string }> };

export async function POST(request: Request, { params }: Params) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });

  const { id } = await params;
  const body = await request.json().catch(() => null);
  const parsed = sendSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  }

  const guest = await prisma.guest.findUnique({ where: { id } });
  if (!guest) return NextResponse.json({ error: "Convidado não encontrado" }, { status: 404 });

  const results = await sendInvite(guest, parsed.data.channels);
  const anySuccess = results.some((r) => r.success);
  return NextResponse.json({ results }, { status: anySuccess ? 200 : 502 });
}
