import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { isAdmin } from "@/lib/auth";

const guestSchema = z.object({
  name: z.string().trim().min(1, "Nome é obrigatório"),
  email: z.string().trim().email("E-mail inválido").optional().or(z.literal("")),
  phone: z.string().trim().optional().or(z.literal("")),
  notes: z.string().trim().optional().or(z.literal("")),
});

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });

  const guests = await prisma.guest.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      messages: { orderBy: { createdAt: "desc" }, take: 5 },
    },
  });
  return NextResponse.json({ guests });
}

export async function POST(request: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });

  const body = await request.json().catch(() => null);
  const parsed = guestSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  }

  const { name, email, phone, notes } = parsed.data;
  if (!email && !phone) {
    return NextResponse.json(
      { error: "Informe pelo menos e-mail ou celular para conseguir enviar o convite" },
      { status: 400 }
    );
  }

  const guest = await prisma.guest.create({
    data: {
      name,
      email: email || null,
      phone: phone || null,
      notes: notes || null,
    },
  });
  return NextResponse.json({ guest }, { status: 201 });
}
