import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

const respondSchema = z.object({
  attending: z.boolean(),
});

type Params = { params: Promise<{ token: string }> };

export async function POST(request: Request, { params }: Params) {
  const { token } = await params;
  const body = await request.json().catch(() => null);
  const parsed = respondSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Resposta inválida" }, { status: 400 });
  }

  const guest = await prisma.guest.findUnique({ where: { token } });
  if (!guest) return NextResponse.json({ error: "Convite não encontrado" }, { status: 404 });

  const updated = await prisma.guest.update({
    where: { token },
    data: {
      saveTheDate: parsed.data.attending ? "YES" : "NO",
      saveTheDateAt: new Date(),
    },
  });

  return NextResponse.json({ status: updated.saveTheDate });
}
