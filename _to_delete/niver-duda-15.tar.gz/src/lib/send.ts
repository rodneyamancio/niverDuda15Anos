import { Resend } from "resend";
import twilio from "twilio";
import { prisma } from "@/lib/prisma";
import { emailHtml, emailSubject, whatsappText } from "@/lib/messages";
import type { Guest } from "@/generated/prisma/client";

export type SendChannel = "email" | "whatsapp";

export interface SendResult {
  channel: SendChannel;
  success: boolean;
  error?: string;
}

/** Normaliza celular BR: remove máscara e garante código do país (+55). */
export function normalizePhone(raw: string): string | null {
  const digits = raw.replace(/\D/g, "");
  if (!digits) return null;
  const cc = process.env.DEFAULT_COUNTRY_CODE ?? "55";
  if (digits.startsWith(cc) && digits.length >= 12) return `+${digits}`;
  if (digits.length === 10 || digits.length === 11) return `+${cc}${digits}`;
  return `+${digits}`;
}

async function sendEmail(guest: Guest): Promise<SendResult> {
  if (!guest.email) return { channel: "email", success: false, error: "Convidado sem e-mail cadastrado" };
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) return { channel: "email", success: false, error: "RESEND_API_KEY não configurada no .env" };

  try {
    const resend = new Resend(apiKey);
    const { error } = await resend.emails.send({
      from: process.env.EMAIL_FROM ?? "onboarding@resend.dev",
      to: guest.email,
      subject: emailSubject(),
      html: emailHtml(guest.name, guest.token),
    });
    if (error) return { channel: "email", success: false, error: error.message };
    return { channel: "email", success: true };
  } catch (e) {
    return { channel: "email", success: false, error: e instanceof Error ? e.message : "Erro desconhecido" };
  }
}

async function sendWhatsApp(guest: Guest): Promise<SendResult> {
  if (!guest.phone) return { channel: "whatsapp", success: false, error: "Convidado sem celular cadastrado" };
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  const from = process.env.TWILIO_WHATSAPP_FROM;
  if (!sid || !token || !from) {
    return { channel: "whatsapp", success: false, error: "Credenciais Twilio não configuradas no .env" };
  }
  const to = normalizePhone(guest.phone);
  if (!to) return { channel: "whatsapp", success: false, error: "Celular inválido" };

  try {
    const client = twilio(sid, token);
    await client.messages.create({
      from: `whatsapp:${from}`,
      to: `whatsapp:${to}`,
      body: whatsappText(guest.name, guest.token),
    });
    return { channel: "whatsapp", success: true };
  } catch (e) {
    return { channel: "whatsapp", success: false, error: e instanceof Error ? e.message : "Erro desconhecido" };
  }
}

export async function sendInvite(guest: Guest, channels: SendChannel[]): Promise<SendResult[]> {
  const results: SendResult[] = [];
  for (const channel of channels) {
    const result = channel === "email" ? await sendEmail(guest) : await sendWhatsApp(guest);
    results.push(result);
    await prisma.messageLog.create({
      data: {
        guestId: guest.id,
        channel: channel === "email" ? "EMAIL" : "WHATSAPP",
        kind: "SAVE_THE_DATE",
        success: result.success,
        error: result.error,
      },
    });
  }
  return results;
}
