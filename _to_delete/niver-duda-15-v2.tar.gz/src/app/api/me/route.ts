import { NextResponse } from "next/server";
import { getRole } from "@/lib/auth";
import { getSettings } from "@/lib/settings";

export async function GET() {
  const role = await getRole();
  if (!role) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
  const settings = await getSettings();
  return NextResponse.json({ role, phase: settings.phase });
}
