import { redirect } from "next/navigation";
import { getRole } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import Dashboard from "./dashboard";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const role = await getRole();
  if (!role) redirect("/admin/login");
  const settings = await getSettings();
  return <Dashboard role={role} phase={settings.phase} eventName={settings.eventName} />;
}
