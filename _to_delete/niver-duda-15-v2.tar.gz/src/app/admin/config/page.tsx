import { redirect } from "next/navigation";
import { getRole } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import ConfigForm from "./config-form";

export const dynamic = "force-dynamic";

export default async function ConfigPage() {
  const role = await getRole();
  if (!role) redirect("/admin/login");
  if (role !== "superadmin") redirect("/admin");
  const settings = await getSettings();
  return <ConfigForm phase={settings.phase} eventName={settings.eventName} />;
}
