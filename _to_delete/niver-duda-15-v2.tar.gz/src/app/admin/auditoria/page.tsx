import { redirect } from "next/navigation";
import { getRole } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import AuditTable from "./audit-table";

export const dynamic = "force-dynamic";

export default async function AuditPage() {
  const role = await getRole();
  if (!role) redirect("/admin/login");
  if (role !== "superadmin") redirect("/admin");
  const settings = await getSettings();
  return <AuditTable phase={settings.phase} eventName={settings.eventName} />;
}
