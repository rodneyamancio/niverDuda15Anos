import { createHmac, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";

const COOKIE_NAME = "admin_session";
const SESSION_HOURS = 24 * 7; // 7 dias

export type Role = "admin" | "superadmin";

function secret(): string {
  const s = process.env.AUTH_SECRET;
  if (!s) throw new Error("AUTH_SECRET não definido no .env");
  return s;
}

function sign(payload: string): string {
  return createHmac("sha256", secret()).update(payload).digest("hex");
}

export function createSessionToken(role: Role): string {
  const exp = Date.now() + SESSION_HOURS * 60 * 60 * 1000;
  const payload = `${exp}.${role}`;
  return `${payload}.${sign(payload)}`;
}

export function verifySessionToken(token: string | undefined): Role | null {
  if (!token) return null;
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  const [exp, role, signature] = parts;
  if (role !== "admin" && role !== "superadmin") return null;
  const expected = sign(`${exp}.${role}`);
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  if (Number(exp) <= Date.now()) return null;
  return role;
}

export async function getRole(): Promise<Role | null> {
  const store = await cookies();
  return verifySessionToken(store.get(COOKIE_NAME)?.value);
}

export async function isAdmin(): Promise<boolean> {
  return (await getRole()) !== null;
}

export async function isSuperAdmin(): Promise<boolean> {
  return (await getRole()) === "superadmin";
}

export async function setSessionCookie(role: Role): Promise<void> {
  const store = await cookies();
  store.set(COOKIE_NAME, createSessionToken(role), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: SESSION_HOURS * 60 * 60,
  });
}

export async function clearSessionCookie(): Promise<void> {
  const store = await cookies();
  store.delete(COOKIE_NAME);
}

function safeEqual(a: string, b: string): boolean {
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  return ba.length === bb.length && timingSafeEqual(ba, bb);
}

/** Retorna o papel correspondente à senha, ou null se não bater com nenhuma. */
export function checkPassword(password: string): Role | null {
  const superPw = process.env.SUPER_ADMIN_PASSWORD;
  const adminPw = process.env.ADMIN_PASSWORD;
  if (superPw && safeEqual(password, superPw)) return "superadmin";
  if (adminPw && safeEqual(password, adminPw)) return "admin";
  return null;
}
